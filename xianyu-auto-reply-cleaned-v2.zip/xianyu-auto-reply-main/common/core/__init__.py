"""Core configuration module."""
